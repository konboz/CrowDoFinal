﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrowDoAPI
{
    public class ProjectMediaOptions
    {
        public string FileName { get; set; }
    }
}
