﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrowDoAPI
{
    public class RewardPackageOptions
    {
        public string PackageName { get; set; }

        public string RewardName { get; set; }

        public decimal Price { get; set; }


    }
}
