﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrowDoAPI
{
    public class StatusUpdateOptions
    {
        public string Text { get; set; }
    }
}
